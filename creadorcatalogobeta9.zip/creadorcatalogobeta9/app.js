'use strict';

/* ══════════════════════════════════════════
   CREADOR DE CATÁLOGO MN LATAM 2026 · v5
   - IndexedDB: artículos + fotos globales + cfg
   - Galería de fotos global: sube todas de una
   - Asigna fotos a artículos desde la galería
   - Fix precio: 17,900 / 24,900 se parsea completo
     (incluye pegado con tabulador, tipo Excel/Sheets)
   - Scroll libre en móvil
   - Reordenar artículos arrastrando (touch + mouse)
   - Buscar/filtrar artículos por nombre
   - Duplicar artículo
   - Lista de precios en PDF (sin imágenes)
   - Imágenes en PDF sin deformar (proporción real)
   - Respaldo completo del catálogo en JSON
══════════════════════════════════════════ */

const STATE = {
  articles: [],   // [{ id, nombre, precio, moneda, badge, descripcion, imgSrc, icon }]
  photos:   [],   // [{ id, name, src }] — galería global
  nextId:   1,
  nextPhotoId: 1,
};

/* ══════════════════════════════════════════
   TEMAS — "rojo" (default) y "premium" (oscuro,
   sin rojo). Se usa TANTO en el catálogo HTML como
   en el PDF, para que ambos se generen siempre con
   el tema activo en ese momento, sin excepción.
   Nota: los nombres de campo htmlAccent/pdfAccent
   son genéricos aunque el tema "rojo" les ponga
   rojo — es el mismo campo el que cambia de color
   según el tema, no una variable nueva por tema.
══════════════════════════════════════════ */
const THEMES = {
  rojo: {
    label: 'Rojo',
    // catálogo HTML (buildCatalogHTML)
    htmlBg: '#121212', htmlCard: '#1e1e1e', htmlBlack: '#050505',
    htmlGray2: '#2a2a2a', htmlGray3: '#777', htmlGray4: '#aaa', htmlText: '#ececec',
    htmlAccent: '#e8001c', htmlAccentDark: '#b30015', htmlAccentRGB: '232,0,28',
    // PDF (generatePDF) — arrays RGB
    pdfBg: [18,18,18], pdfCard: [30,30,30], pdfAccent: [232,0,28],
    pdfText: [236,236,236], pdfGr2: [42,42,42], pdfGr3: [119,119,119], pdfGr4: [170,170,170],
    pdfChipBg: [45,10,12],
    // acento para PDFs de fondo CLARO (lista de precios) — el pdfAccent
    // normal está pensado para resaltar sobre fondo oscuro, así que aquí
    // se define aparte para que también se vea bien sobre blanco
    lightAccent: [232,0,28],
  },
  premium: {
    label: 'Oscuro Premium',
    htmlBg: '#000000', htmlCard: '#161616', htmlBlack: '#000000',
    htmlGray2: '#333333', htmlGray3: '#888888', htmlGray4: '#cccccc', htmlText: '#ffffff',
    htmlAccent: '#d4d4d4', htmlAccentDark: '#a8a8a8', htmlAccentRGB: '212,212,212',
    pdfBg: [0,0,0], pdfCard: [22,22,22], pdfAccent: [212,212,212],
    pdfText: [255,255,255], pdfGr2: [40,40,40], pdfGr3: [136,136,136], pdfGr4: [190,190,190],
    pdfChipBg: [35,35,35],
    lightAccent: [45,45,45],
  },
};
function getActiveTheme() {
  const key = getCfg('cfg-tema');
  return THEMES[key] || THEMES.rojo;
}

/* ══ IndexedDB ══ */
const DB_NAME    = 'mnlatam_catalogo_2026';
const DB_VER     = 2;
const ST_ART     = 'articles';
const ST_PHO     = 'photos';
const ST_CFG     = 'config';
let   _db        = null;

function abrirDB() {
  return new Promise((res, rej) => {
    if (_db) { res(_db); return; }
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(ST_ART)) db.createObjectStore(ST_ART, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(ST_PHO)) db.createObjectStore(ST_PHO, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(ST_CFG)) db.createObjectStore(ST_CFG, { keyPath: 'key' });
    };
    req.onsuccess = e => { _db = e.target.result; res(_db); };
    req.onerror   = e => rej(e.target.error);
  });
}

async function dbPut(store, obj) {
  const db = await abrirDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).put(obj);
    tx.oncomplete = () => res();
    tx.onerror    = e => rej(e.target.error);
  });
}

async function dbDelete(store, id) {
  const db = await abrirDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).delete(id);
    tx.oncomplete = () => res();
    tx.onerror    = e => rej(e.target.error);
  });
}

async function dbGetAll(store) {
  const db = await abrirDB();
  return new Promise((res, rej) => {
    const items = [];
    const tx    = db.transaction(store, 'readonly');
    tx.objectStore(store).openCursor().onsuccess = e => {
      const cur = e.target.result;
      if (cur) { items.push(cur.value); cur.continue(); }
    };
    tx.oncomplete = () => res(items);
    tx.onerror    = e => rej(e.target.error);
  });
}

async function dbClear(store) {
  const db = await abrirDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).clear();
    tx.oncomplete = () => res();
    tx.onerror    = e => rej(e.target.error);
  });
}

/* ══ Utils ══ */
const ICONS = ['👟','👠','🧢','🎒','👜','🕶️','⌚','💎','🧤','🧣','👒','🥿','👞','🩴','💍','🧳','👕','🩳','🧥'];
let iconIdx = 0;
function nextIcon() { return ICONS[iconIdx++ % ICONS.length]; }

let _toastT;
function showToast(msg, type = '', dur = 2800) {
  clearTimeout(_toastT);
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = 'show ' + type;
  _toastT = setTimeout(() => { t.className = ''; }, dur);
}

function uid()      { return 'a' + (STATE.nextId++); }
function uidPhoto() { return 'p' + (STATE.nextPhotoId++); }
function sleep(ms)  { return new Promise(r => setTimeout(r, ms)); }

function escHtml(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function formatPrecio(p) {
  const n = parseFloat(String(p).replace(/,/g, ''));
  if (isNaN(n)) return String(p);
  return n.toLocaleString('es-MX');
}

/* ══════════════════════════════════════════
   GALERÍA GLOBAL DE FOTOS
══════════════════════════════════════════ */
const photosInput   = document.getElementById('photos-input');
const photosZone    = document.getElementById('photos-upload-zone');
const photosGrid    = document.getElementById('photos-grid');
const photosWrap    = document.getElementById('photos-gallery-wrap');
const photosCountEl = document.getElementById('photos-count');

photosZone.addEventListener('click', () => photosInput.click());
photosZone.addEventListener('dragover',  e => { e.preventDefault(); photosZone.classList.add('drag-over'); });
photosZone.addEventListener('dragleave', () => photosZone.classList.remove('drag-over'));
photosZone.addEventListener('drop', e => { e.preventDefault(); photosZone.classList.remove('drag-over'); loadPhotos(e.dataTransfer.files); });
photosInput.addEventListener('change', e => { loadPhotos(e.target.files); photosInput.value = ''; });

document.getElementById('btn-clear-photos').addEventListener('click', async () => {
  if (!confirm('¿Eliminar todas las fotos de la galería?')) return;
  STATE.photos = [];
  await dbClear(ST_PHO);
  renderPhotosGrid();
  showToast('Galería limpiada', 'ok');
});

function loadPhotos(files) {
  const imgs = Array.from(files).filter(f => f.type.startsWith('image/'));
  if (!imgs.length) { showToast('Solo imágenes', 'err'); return; }
  showToast(`Cargando ${imgs.length} foto${imgs.length > 1 ? 's' : ''}…`, '', 9999);
  let done = 0;
  imgs.forEach(file => {
    const reader = new FileReader();
    reader.onload = async e => {
      const photo = { id: uidPhoto(), name: file.name, src: e.target.result };
      STATE.photos.push(photo);
      await dbPut(ST_PHO, photo);
      done++;
      if (done === imgs.length) {
        renderPhotosGrid();
        showToast(`✓ ${done} foto${done > 1 ? 's' : ''} guardada${done > 1 ? 's' : ''}`, 'ok');
      }
    };
    reader.readAsDataURL(file);
  });
}

function renderPhotosGrid() {
  photosGrid.innerHTML = '';
  const count = STATE.photos.length;
  photosCountEl.textContent = count;

  if (count === 0) {
    photosWrap.classList.add('hidden');
    return;
  }
  photosWrap.classList.remove('hidden');

  STATE.photos.forEach(photo => {
    const div  = document.createElement('div');
    div.className = 'photo-thumb';
    div.dataset.id = photo.id;

    const isUsed = STATE.articles.some(a => a.imgSrc === photo.src);
    if (isUsed) {
      div.classList.add('used');
      const badge = document.createElement('div');
      badge.className = 'pt-used-badge';
      badge.textContent = 'EN USO';
      div.appendChild(badge);
    }

    const img = document.createElement('img');
    img.src = photo.src; img.alt = photo.name; img.loading = 'lazy';
    div.appendChild(img);

    const del = document.createElement('div');
    del.className = 'pt-del';
    del.textContent = 'ELIMINAR';
    div.appendChild(del);

    // Toque largo para eliminar
    let longPress;
    div.addEventListener('touchstart', () => {
      longPress = setTimeout(async () => {
        if (!confirm(`¿Eliminar "${photo.name}"?`)) return;
        STATE.photos = STATE.photos.filter(p => p.id !== photo.id);
        await dbDelete(ST_PHO, photo.id);
        renderPhotosGrid();
        showToast('Foto eliminada', 'ok');
      }, 700);
    }, { passive: true });
    div.addEventListener('touchend', () => clearTimeout(longPress));
    div.addEventListener('touchmove', () => clearTimeout(longPress));

    photosGrid.appendChild(div);
  });
}

/* ══════════════════════════════════════════
   MODAL SELECCIONAR FOTO → ARTÍCULO
══════════════════════════════════════════ */
let _pickingForArtId = null;

function abrirPickFotos(artId) {
  _pickingForArtId = artId;
  const grid = document.getElementById('modal-pick-grid');
  grid.innerHTML = '';

  if (STATE.photos.length === 0) {
    grid.innerHTML = '<div class="pick-empty">No tienes fotos en la galería.<br>Sube fotos primero usando el área de fotos.</div>';
  } else {
    STATE.photos.forEach(photo => {
      const div = document.createElement('div');
      div.className = 'pick-thumb';
      const img = document.createElement('img');
      img.src = photo.src; img.alt = photo.name; img.loading = 'lazy';
      div.appendChild(img);
      div.addEventListener('click', async () => {
        await updateField(artId, 'imgSrc', photo.src);
        const card = document.querySelector(`[data-id="${artId}"]`);
        if (card) applyImg(card, artId, photo.src);
        cerrarPickFotos();
        renderPhotosGrid(); // actualizar badge "EN USO"
        showToast('✓ Foto asignada', 'ok');
      });
      grid.appendChild(div);
    });
  }

  document.getElementById('modal-pick-photos').classList.remove('hidden');
}

function cerrarPickFotos() {
  _pickingForArtId = null;
  document.getElementById('modal-pick-photos').classList.add('hidden');
}

document.getElementById('btn-pick-cancel').addEventListener('click', cerrarPickFotos);
document.getElementById('modal-pick-photos').addEventListener('click', e => {
  if (e.target.id === 'modal-pick-photos') cerrarPickFotos();
});

/* ══════════════════════════════════════════
   PARSEAR LISTA PEGADA
   Fix: maneja precios largos sin comas (17900, 24900...)
   sin truncarlos, y separadores de tabulador (pegado
   directo desde Excel / Google Sheets de 2 columnas).
   Estrategia:
   1. Detectar precio con $ o MXN/USD explícito
   2. El separador de miles NO confunde el parseo
══════════════════════════════════════════ */
function parsePastedList(text) {
  const lines  = text.split('\n').map(l => l.trim()).filter(Boolean);
  const result = [];

  for (const line of lines) {
    let nombre = '', precio = '', moneda = 'MXN';

    // pxRgx: $ + número completo (sin límite de dígitos, con o sin comas)
    // Bug evitado: [\d]{1,3} solo capturaba hasta 3 dígitos → $24900 → $249
    const pxRgx = /\$\s*(\d[\d,]*(?:\.\d+)?)\s*(MXN|USD|mxn|usd|pesos)?/i;
    // mnRgx: número seguido de moneda explícita
    const mnRgx = /(\d[\d,]*(?:\.\d+)?)\s*(MXN|USD|mxn|usd|pesos)/i;

    let m = line.match(pxRgx) || line.match(mnRgx);

    if (m) {
      precio = m[1].replace(/,/g, '');
      moneda = (m[2] || 'MXN').toUpperCase();
      if (moneda === 'PESOS') moneda = 'MXN';
      // Nombre = todo lo que NO es el precio, limpiando separadores y viñetas
      nombre = line.replace(m[0], '')
        .replace(/[\s,\-–—]+$/, '')
        .replace(/^\s*[*•·\-–—|,]\s*/, '')
        .replace(/\s{2,}/g, ' ')
        .trim();
    } else {
      // Sin precio con moneda — separador doble, pipe, o TAB (Excel/Sheets)
      const sepRgx = /\s+[-–—|]{1,2}\s+|\t/;
      const parts  = line.split(sepRgx).map(p => p.trim()).filter(Boolean);
      if (parts.length >= 2) {
        const last = parts[parts.length - 1];
        if (/^\d[\d,.]*$/.test(last)) {
          precio = last.replace(/,/g, '');
          nombre = parts.slice(0, -1).join(' ').replace(/^\s*[*•·,]\s*/, '').trim();
        } else {
          nombre = line.replace(/^\s*[*•·,]\s*/, '').trim();
        }
      } else {
        nombre = line.replace(/^\s*[*•·,]\s*/, '').trim();
      }
    }

    nombre = nombre.replace(/^\$\s*/, '').replace(/\s{2,}/g, ' ').trim();
    if (!nombre) continue;

    result.push({ nombre, precio, moneda });
  }
  return result;
}

/* ══════════════════════════════════════════
   ARTÍCULOS
══════════════════════════════════════════ */
async function addArticle(data = {}, skipDB = false) {
  const art = {
    id:          data.id          || uid(),
    nombre:      data.nombre      || '',
    precio:      data.precio      || '',
    moneda:      data.moneda      || 'MXN',
    badge:       data.badge       || 'DISPONIBLE',
    descripcion: data.descripcion || '',
    imgSrc:      data.imgSrc      || null,
    icon:        data.icon        || nextIcon(),
    orden:       data.orden       !== undefined ? data.orden : STATE.articles.length,
  };
  STATE.articles.push(art);
  if (!skipDB) await dbPut(ST_ART, art);
  renderArticleCard(art);
  updateEmptyState();
  return art;
}

async function removeArticle(id) {
  STATE.articles = STATE.articles.filter(a => a.id !== id);
  document.querySelector(`.article-card[data-id="${id}"]`)?.remove();
  renumberCards();
  updateEmptyState();
  renderPhotosGrid();
  await dbDelete(ST_ART, id);
}

/* ══ LIMPIAR LISTA — nueva sesión ══
   Solo borra los artículos; las fotos de la galería
   se conservan porque suelen reutilizarse en el
   siguiente catálogo. */
async function clearAllArticles() {
  if (!STATE.articles.length) { showToast('No hay artículos para borrar', 'err'); return; }
  if (!confirm('¿Borrar TODOS los artículos de la lista?\n\nEsta acción no se puede deshacer. Tus fotos guardadas en la galería NO se borrarán.')) return;

  await dbClear(ST_ART);
  STATE.articles = [];
  STATE.nextId   = 1;
  iconIdx        = 0;
  document.getElementById('articles-list').innerHTML = '';
  updateEmptyState();
  renderPhotosGrid();
  showToast('✓ Lista limpiada. ¡Listo para empezar de nuevo!', 'ok', 3000);
}

/* ══ DUPLICAR ARTÍCULO ══ */
async function duplicateArticle(id) {
  const original = getArticle(id);
  if (!original) return;
  const clone = await addArticle({
    nombre:      (original.nombre || 'Artículo') + ' (copia)',
    precio:      original.precio,
    moneda:      original.moneda,
    badge:       original.badge,
    descripcion: original.descripcion,
    imgSrc:      original.imgSrc,
    icon:        original.icon,
  });
  showToast('✓ Artículo duplicado', 'ok');
  setTimeout(() => {
    const el = document.querySelector(`.article-card[data-id="${clone.id}"]`);
    if (el) { el.classList.add('open'); el.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  }, 50);
}

function getArticle(id) { return STATE.articles.find(a => a.id === id); }

async function updateField(id, field, value) {
  const art = getArticle(id);
  if (!art) return;
  art[field] = value;
  await dbPut(ST_ART, art);
}

function renumberCards() {
  document.querySelectorAll('.article-card .article-num').forEach((el, i) => {
    el.textContent = String(i + 1).padStart(2, '0');
  });
}

function updateEmptyState() {
  const list = document.getElementById('articles-list');
  let es      = list.querySelector('.empty-state');
  const query = document.getElementById('articles-search')?.value.trim() || '';
  const visibles = list.querySelectorAll('.article-card:not(.search-hidden)').length;

  const ensureEs = () => {
    if (!es) {
      es = document.createElement('div');
      es.className = 'empty-state';
      list.appendChild(es);
    }
    return es;
  };

  if (!STATE.articles.length) {
    ensureEs().innerHTML = `<div class="es-icon">📦</div>
      <div class="es-title">Sin artículos</div>
      <div class="es-text">Agrega artículos uno por uno o pega tu lista completa.</div>`;
  } else if (query && visibles === 0) {
    ensureEs().innerHTML = `<div class="es-icon">🔍</div>
      <div class="es-title">Sin resultados</div>
      <div class="es-text">Ningún artículo coincide con "${escHtml(query)}".</div>`;
  } else {
    es?.remove();
  }
}

/* ══════════════════════════════════════════
   BUSCAR / FILTRAR ARTÍCULOS POR NOMBRE
══════════════════════════════════════════ */
function filterArticles(query) {
  const q = query.trim().toLowerCase();
  document.querySelectorAll('#articles-list .article-card').forEach(card => {
    const art   = getArticle(card.dataset.id);
    const match = !q || (art && art.nombre.toLowerCase().includes(q));
    card.classList.toggle('search-hidden', !match);
  });
  updateEmptyState();
}

/* ══════════════════════════════════════════
   RENDER TARJETA DE ARTÍCULO
══════════════════════════════════════════ */
function renderArticleCard(art) {
  const list = document.getElementById('articles-list');
  const idx  = STATE.articles.findIndex(a => a.id === art.id) + 1;

  const card = document.createElement('div');
  card.className  = 'article-card';
  card.dataset.id = art.id;

  card.innerHTML = `
    <div class="article-card-header">
      <span class="article-drag-handle" title="Arrastra para reordenar">⠿</span>
      <span class="article-num">${String(idx).padStart(2,'0')}</span>
      <span class="article-name-preview">${art.nombre || 'Sin nombre'}</span>
      <span class="article-price-preview">${art.precio ? '$'+formatPrecio(art.precio)+' '+art.moneda : '—'}</span>
      <span class="article-toggle">▾</span>
      <button class="article-delete">✕</button>
    </div>
    <div class="article-card-body">
      <div class="article-fields">
        <div class="article-field full">
          <label>Nombre del artículo</label>
          <input type="text" class="f-nombre" value="${escHtml(art.nombre)}" placeholder="Ej: Nike Air Max 270">
        </div>
        <div class="article-field">
          <label>Precio (solo números)</label>
          <input type="text" class="f-precio" inputmode="numeric" value="${escHtml(art.precio)}" placeholder="17900">
        </div>
        <div class="article-field">
          <label>Moneda</label>
          <select class="f-moneda">
            <option value="MXN"   ${art.moneda==='MXN'?'selected':''}>MXN</option>
            <option value="USD"   ${art.moneda==='USD'?'selected':''}>USD</option>
            <option value="PESOS" ${art.moneda==='PESOS'?'selected':''}>PESOS</option>
          </select>
        </div>
        <div class="article-field">
          <label>Badge / Etiqueta</label>
          <input type="text" class="f-badge" value="${escHtml(art.badge)}" placeholder="DISPONIBLE">
        </div>
        <div class="article-field full">
          <label>Descripción (opcional)</label>
          <textarea class="f-desc" rows="2" placeholder="Descripción breve...">${escHtml(art.descripcion)}</textarea>
        </div>
      </div>
      <div class="article-img-wrap">
        <label>Imagen del artículo</label>
        <button class="btn-pick-from-gallery" type="button">🖼️ Seleccionar foto de la galería</button>
        <div class="article-img-zone" id="imgzone-${art.id}">
          <div class="img-placeholder">
            <div class="img-label">O toca aquí para subir desde tu galería <span>(opcional)</span></div>
          </div>
          <input type="file" accept="image/*" style="display:none" class="f-img-input">
          <button class="article-img-remove" type="button">✕</button>
        </div>
      </div>
      <div class="article-card-footer-actions">
        <button class="btn-ghost-sm btn-duplicate" type="button">⎘ Duplicar artículo</button>
      </div>
    </div>
  `;

  // Toggle
  card.querySelector('.article-card-header').addEventListener('click', e => {
    if (e.target.classList.contains('article-delete')) return;
    if (e.target.closest('.article-drag-handle')) return;
    card.classList.toggle('open');
  });

  // Eliminar
  card.querySelector('.article-delete').addEventListener('click', async e => {
    e.stopPropagation();
    await removeArticle(art.id);
  });

  // Bind campos
  const bind = (sel, field) => {
    const el = card.querySelector(sel);
    if (!el) return;
    el.addEventListener('input', async () => {
      await updateField(art.id, field, el.value);
      if (field === 'nombre') card.querySelector('.article-name-preview').textContent = el.value || 'Sin nombre';
      if (field === 'precio' || field === 'moneda') {
        const a = getArticle(art.id);
        card.querySelector('.article-price-preview').textContent = a.precio ? '$'+formatPrecio(a.precio)+' '+a.moneda : '—';
      }
    });
  };
  bind('.f-nombre', 'nombre');
  bind('.f-precio', 'precio');
  bind('.f-badge',  'badge');
  bind('.f-desc',   'descripcion');
  card.querySelector('.f-moneda')?.addEventListener('change', async e => {
    await updateField(art.id, 'moneda', e.target.value);
    const a = getArticle(art.id);
    card.querySelector('.article-price-preview').textContent = a.precio ? '$'+formatPrecio(a.precio)+' '+a.moneda : '—';
  });

  // Botón seleccionar de galería
  card.querySelector('.btn-pick-from-gallery').addEventListener('click', () => {
    abrirPickFotos(art.id);
  });

  // Duplicar
  card.querySelector('.btn-duplicate').addEventListener('click', () => duplicateArticle(art.id));

  // Subir imagen directo
  setupImgZone(card, art.id);
  if (art.imgSrc) applyImg(card, art.id, art.imgSrc);

  // Reordenar arrastrando
  setupDragReorder(card, art.id);

  list.appendChild(card);
}

function setupImgZone(card, artId) {
  const zone  = card.querySelector(`#imgzone-${artId}`);
  const input = zone.querySelector('.f-img-input');
  const rmBtn = zone.querySelector('.article-img-remove');

  zone.addEventListener('click', e => {
    if (e.target === rmBtn || rmBtn.contains(e.target)) return;
    if (zone.classList.contains('has-img')) return;
    input.click();
  });

  input.addEventListener('change', () => {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async ev => {
      await updateField(artId, 'imgSrc', ev.target.result);
      applyImg(card, artId, ev.target.result);
    };
    reader.readAsDataURL(file);
  });

  rmBtn.addEventListener('click', async e => {
    e.stopPropagation();
    await updateField(artId, 'imgSrc', null);
    zone.classList.remove('has-img');
    zone.querySelector('img')?.remove();
    zone.querySelector('.img-placeholder').style.display = '';
    input.value = '';
    renderPhotosGrid();
  });
}

function applyImg(card, artId, src) {
  const zone = card.querySelector(`#imgzone-${artId}`);
  zone.classList.add('has-img');
  let img = zone.querySelector('img');
  if (!img) { img = document.createElement('img'); zone.insertBefore(img, zone.querySelector('.article-img-remove')); }
  img.src = src;
  zone.querySelector('.img-placeholder').style.display = 'none';
}

/* ══════════════════════════════════════════
   REORDENAR ARTÍCULOS ARRASTRANDO
   Pointer Events (funciona con dedo, mouse y stylus).
   Se "levanta" la tarjeta con position:fixed y se deja
   un placeholder en su lugar dentro de la lista; el
   placeholder se mueve según la posición del dedo. Al
   soltar, la tarjeta real se inserta donde quedó el
   placeholder y se guarda el nuevo orden.
══════════════════════════════════════════ */
let _drag = null;

function setupDragReorder(card, artId) {
  const handle = card.querySelector('.article-drag-handle');
  if (!handle) return;

  handle.addEventListener('pointerdown', e => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();

    const rect = card.getBoundingClientRect();
    const placeholder = document.createElement('div');
    placeholder.className = 'article-card-placeholder';
    placeholder.style.height = rect.height + 'px';
    card.parentNode.insertBefore(placeholder, card.nextSibling);

    _drag = { card, placeholder, grabOffsetY: e.clientY - rect.top, moved: false };

    card.style.width = rect.width + 'px';
    card.style.left  = rect.left + 'px';
    card.style.top   = rect.top + 'px';
    card.classList.add('dragging');
    document.body.classList.add('is-dragging-card');

    try { handle.setPointerCapture(e.pointerId); } catch (_) {}
  });

  handle.addEventListener('pointermove', e => {
    if (!_drag || _drag.card !== card) return;
    e.preventDefault();
    _drag.moved = true;

    card.style.top = (e.clientY - _drag.grabOffsetY) + 'px';

    const list = document.getElementById('articles-list');
    const siblings = Array.from(list.querySelectorAll('.article-card'))
      .filter(el => el !== card && !el.classList.contains('search-hidden'));

    let target = null;
    for (const sib of siblings) {
      const r = sib.getBoundingClientRect();
      if (e.clientY < r.top + r.height / 2) { target = sib; break; }
    }
    if (target) {
      if (target.previousElementSibling !== _drag.placeholder) list.insertBefore(_drag.placeholder, target);
    } else if (list.lastElementChild !== _drag.placeholder) {
      list.appendChild(_drag.placeholder);
    }
  });

  const finishDrag = async () => {
    if (!_drag || _drag.card !== card) return;
    const { placeholder, moved } = _drag;
    const list = document.getElementById('articles-list');
    list.insertBefore(card, placeholder);
    placeholder.remove();

    card.classList.remove('dragging');
    card.style.position = '';
    card.style.top = '';
    card.style.left = '';
    card.style.width = '';
    document.body.classList.remove('is-dragging-card');
    _drag = null;

    if (moved) await persistArticleOrder();
  };

  handle.addEventListener('pointerup', finishDrag);
  handle.addEventListener('pointercancel', finishDrag);
}

async function persistArticleOrder() {
  const list = document.getElementById('articles-list');
  const ids  = Array.from(list.querySelectorAll('.article-card')).map(c => c.dataset.id);
  const reordered = [];
  ids.forEach((id, i) => {
    const art = getArticle(id);
    if (art) { art.orden = i; reordered.push(art); }
  });
  STATE.articles = reordered;
  renumberCards();
  for (const art of reordered) await dbPut(ST_ART, art);
  showToast('✓ Orden actualizado', 'ok', 1600);
}

/* ══════════════════════════════════════════
   CONFIG — persistencia
══════════════════════════════════════════ */
const CFG_IDS = ['cfg-chip','cfg-title-red','cfg-title-rest','cfg-desc','cfg-section-label','cfg-section-title','cfg-wa','cfg-wa-btn','cfg-footer','cfg-tema','cfg-gemini-key'];

function bindCfg() {
  CFG_IDS.forEach(id => {
    document.getElementById(id)?.addEventListener('input', e => dbPut(ST_CFG, { key: id, val: e.target.value }));
  });
  document.querySelectorAll('.stat-row').forEach((row, i) => {
    row.querySelector('.stat-val')?.addEventListener('input', e => dbPut(ST_CFG, { key: 'sv'+i, val: e.target.value }));
    row.querySelector('.stat-lbl')?.addEventListener('input', e => dbPut(ST_CFG, { key: 'sl'+i, val: e.target.value }));
  });
}

function restoreCfg(cfgs) {
  const m = {};
  cfgs.forEach(c => { m[c.key] = c.val; });
  CFG_IDS.forEach(id => { if (m[id] !== undefined) { const el = document.getElementById(id); if (el) el.value = m[id]; } });
  document.querySelectorAll('.stat-row').forEach((row, i) => {
    if (m['sv'+i] !== undefined) row.querySelector('.stat-val').value = m['sv'+i];
    if (m['sl'+i] !== undefined) row.querySelector('.stat-lbl').value = m['sl'+i];
  });
  // Sincronizar el toggle visual del tema con el valor restaurado
  const temaActivo = document.getElementById('cfg-tema')?.value || 'rojo';
  document.querySelectorAll('.theme-opt').forEach(b => b.classList.toggle('active', b.dataset.theme === temaActivo));
}

/* ══════════════════════════════════════════
   RESPALDO — exportar / importar todo en JSON
   Útil para no perder el catálogo si se borra el
   navegador o al cambiar de celular, ya que todo
   vive solo en este dispositivo (IndexedDB).
══════════════════════════════════════════ */
function exportBackupJSON() {
  const cfgValues = {};
  CFG_IDS.forEach(id => { cfgValues[id] = getCfg(id); });
  document.querySelectorAll('.stat-row').forEach((row, i) => {
    cfgValues['sv'+i] = row.querySelector('.stat-val')?.value || '';
    cfgValues['sl'+i] = row.querySelector('.stat-lbl')?.value || '';
  });

  const backup = {
    tipo:     'mnlatam_catalogo_backup',
    version:  1,
    fecha:    new Date().toISOString(),
    articles: STATE.articles,
    photos:   STATE.photos,
    config:   cfgValues,
  };

  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  const fecha = new Date().toISOString().slice(0, 10);
  a.href = url; a.download = `respaldo_catalogo_${fecha}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('✓ Respaldo descargado', 'ok');
}

/* ══════════════════════════════════════════
   PUBLICAR A LA TIENDA — convierte los artículos de este
   Creador de Catálogos al formato que lee la tienda en línea
   (el proyecto aparte con carrito, checkout y ticket en PDF).

   Descarga "productos.json". Ese archivo se coloca en la raíz
   del proyecto de la tienda (reemplazando el que ya tenga) y se
   vuelve a publicar en Netlify/GitHub Pages. La tienda detecta
   que cambió el "version" (la fecha) y actualiza el catálogo
   que ven los clientes, incluso si ya habían entrado antes.

   No modifica nada de este Creador: tus artículos, fotos y
   configuración se quedan igual, esto solo genera una copia
   convertida.
══════════════════════════════════════════ */
/* Reduce una foto (base64) a un tamaño razonable para catálogo web.
   Sin esto, cada foto de celular sin comprimir puede pesar varios MB, y con
   20-30 artículos el productos.json fácilmente pasa de 20MB — más de lo que
   un navegador deja guardar en localStorage (~5-10MB), por lo que la tienda
   se queda sin poder guardar el catálogo y no aparece nada. */
function comprimirImagenBase64(dataUrl, maxDim = 500, calidad = 0.72) {
  return new Promise((resolve) => {
    if (!dataUrl) { resolve(''); return; }
    const img = new Image();
    img.onload = () => {
      let w = img.width, h = img.height;
      if (w > maxDim || h > maxDim) {
        if (w >= h) { h = Math.round(h * maxDim / w); w = maxDim; }
        else { w = Math.round(w * maxDim / h); h = maxDim; }
      }
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      canvas.getContext('2d').drawImage(img, 0, 0, w, h);
      resolve(canvas.toDataURL('image/jpeg', calidad));
    };
    img.onerror = () => resolve(''); /* si una foto falla, se exporta sin foto en vez de tronar todo */
    img.src = dataUrl;
  });
}

async function exportarParaTienda() {
  if (!STATE.articles.length) {
    showToast('Agrega al menos un artículo antes de publicar', 'err');
    return;
  }

  showToast('Preparando productos.json (comprimiendo fotos)…', 'ok');

  const productos = await Promise.all(STATE.articles.map(async (art) => ({
    id: art.id,
    nombre: art.nombre || 'Producto',
    precio: parseFloat(String(art.precio || 0).replace(/,/g, '')) || 0,
    categoria: 'Ropa',
    disponible: String(art.badge || '').toUpperCase().indexOf('AGOTADO') === -1,
    imagen: await comprimirImagenBase64(art.imgSrc || '')
  })));

  const salida = {
    version: new Date().toISOString(),
    productos
  };

  const json = JSON.stringify(salida);
  const blob = new Blob([json], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = 'productos.json';
  a.click();
  URL.revokeObjectURL(url);

  const pesoMB = (blob.size / (1024 * 1024)).toFixed(2);
  const aviso = blob.size > 4 * 1024 * 1024
    ? ` — pesa ${pesoMB} MB, podría no guardarse en algunos navegadores. Considera menos artículos o fotos más simples.`
    : ` (${pesoMB} MB)`;
  showToast(`✓ productos.json descargado${aviso}`, blob.size > 4 * 1024 * 1024 ? 'err' : 'ok');
}

async function importBackupJSON(file) {
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    if (!data || data.tipo !== 'mnlatam_catalogo_backup' || !Array.isArray(data.articles)) {
      showToast('Archivo de respaldo no válido', 'err');
      return;
    }
    if (!confirm('Esto reemplazará tus artículos, fotos y configuración actuales por los del respaldo.\n\n¿Continuar?')) return;

    await dbClear(ST_ART);
    await dbClear(ST_PHO);
    STATE.articles = [];
    STATE.photos = [];
    STATE.nextId = 1;
    STATE.nextPhotoId = 1;
    document.getElementById('articles-list').innerHTML = '';

    // Fotos primero, para que estén listas al pintar artículos
    if (Array.isArray(data.photos)) {
      for (const photo of data.photos) {
        STATE.photos.push(photo);
        await dbPut(ST_PHO, photo);
      }
      const maxP = STATE.photos.reduce((mx, p) => Math.max(mx, parseInt(String(p.id).replace('p','')) || 0), 0);
      STATE.nextPhotoId = maxP + 1;
      renderPhotosGrid();
    }

    // Artículos, respetando el orden guardado
    const arts = data.articles.slice().sort((a,b) => (a.orden||0) - (b.orden||0));
    for (const art of arts) await addArticle(art, false);
    const maxN = STATE.articles.reduce((mx, a) => Math.max(mx, parseInt(String(a.id).replace('a','')) || 0), 0);
    STATE.nextId = maxN + 1;

    // Configuración
    if (data.config) {
      for (const [key, val] of Object.entries(data.config)) await dbPut(ST_CFG, { key, val });
      restoreCfg(Object.entries(data.config).map(([key, val]) => ({ key, val })));
    }

    updateEmptyState();
    showToast(`✓ Respaldo restaurado: ${STATE.articles.length} artículo(s)`, 'ok', 3500);
  } catch (err) {
    console.error(err);
    showToast('Error al leer el respaldo: ' + err.message, 'err');
  }
}

/* ══════════════════════════════════════════
   INIT
══════════════════════════════════════════ */
async function init() {
  try {
    const [arts, photos, cfgs] = await Promise.all([
      dbGetAll(ST_ART),
      dbGetAll(ST_PHO),
      dbGetAll(ST_CFG),
    ]);

    // Restaurar config
    restoreCfg(cfgs);

    // Restaurar fotos globales
    if (photos.length) {
      const maxP = photos.reduce((mx, p) => Math.max(mx, parseInt(p.id.replace('p','')) || 0), 0);
      STATE.nextPhotoId = maxP + 1;
      STATE.photos = photos;
      renderPhotosGrid();
    }

    // Restaurar artículos
    if (arts.length) {
      const maxN = arts.reduce((mx, a) => Math.max(mx, parseInt(a.id.replace('a','')) || 0), 0);
      STATE.nextId = maxN + 1;
      arts.sort((a,b) => (a.orden||0) - (b.orden||0));
      for (const art of arts) {
        STATE.articles.push(art);
        renderArticleCard(art);
      }
      showToast(`✓ ${arts.length} artículo${arts.length>1?'s':''} restaurado${arts.length>1?'s':''}`, 'ok', 2500);
    }
  } catch(e) { console.error('Init error:', e); }

  updateEmptyState();
  bindCfg();

  // Mostrar el tutorial solo la primera vez que se abre la app
  try {
    if (!localStorage.getItem('mnlatam_tutorial_visto')) {
      setTimeout(openTutorial, 500);
    }
  } catch (_) { /* localStorage puede fallar en modo privado; no es crítico */ }
}

/* ══════════════════════════════════════════
   TUTORIAL
══════════════════════════════════════════ */
function openTutorial() {
  document.getElementById('modal-tutorial').classList.remove('hidden');
  try { localStorage.setItem('mnlatam_tutorial_visto', '1'); } catch (_) {}
}
function closeTutorial() {
  document.getElementById('modal-tutorial').classList.add('hidden');
}

/* ══════════════════════════════════════════
   GENERAR HTML
══════════════════════════════════════════ */
function getCfg(id) { return document.getElementById(id)?.value?.trim() || ''; }

function buildCatalogHTML() {
  const theme     = getActiveTheme();
  const chip      = getCfg('cfg-chip');
  const titleRed  = getCfg('cfg-title-red');
  const titleRest = getCfg('cfg-title-rest');
  const desc      = getCfg('cfg-desc');
  const secLabel  = getCfg('cfg-section-label');
  const secTitle  = getCfg('cfg-section-title');
  const waNum     = getCfg('cfg-wa');
  const waBtn     = getCfg('cfg-wa-btn');
  const footer    = getCfg('cfg-footer');

  const statsHTML = Array.from(document.querySelectorAll('.stat-row')).map(row => {
    const v = row.querySelector('.stat-val')?.value || '';
    const l = row.querySelector('.stat-lbl')?.value || '';
    return v||l ? `<div class="stat"><div class="stat-num">${escHtml(v)}</div><div class="stat-label">${escHtml(l)}</div></div>` : '';
  }).join('');

  const productsHTML = STATE.articles.map(art => {
    const imgPart  = art.imgSrc ? `<div class="pkg-img"><img src="${art.imgSrc}" alt="${escHtml(art.nombre)}" loading="lazy"></div>` : '';
    const descPart = art.descripcion ? `<div class="pkg-desc">${escHtml(art.descripcion)}</div>` : '';
    const precioFmt = art.precio ? '$'+formatPrecio(art.precio) : '';
    const pricePart = precioFmt
      ? `<div class="pkg-price">${escHtml(precioFmt)} <small>${escHtml(art.moneda)}</small></div>`
      : `<div class="pkg-price" style="color:var(--gray3);font-size:14px">Consultar precio</div>`;
    return `
    <div class="pkg-card">
      <span class="pkg-badge">${escHtml(art.badge || 'DISPONIBLE')}</span>
      <div class="pkg-name">${escHtml(art.nombre)}</div>
      ${descPart}${imgPart}
      <div class="pkg-divider"></div>
      ${pricePart}
      <button class="pkg-btn" data-producto="${escHtml(art.nombre)}" data-precio="${escHtml(precioFmt ? precioFmt+' '+art.moneda : 'Consultar')}">SOLICITAR →</button>
    </div>`;
  }).join('\n');

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escHtml(titleRed+' '+titleRest)} — Catálogo 2026</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Bebas+Neue&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:${theme.htmlBg};--white:${theme.htmlCard};--black:${theme.htmlBlack};--gray2:${theme.htmlGray2};--gray3:${theme.htmlGray3};--gray4:${theme.htmlGray4};--red:${theme.htmlAccent};--red-dark:${theme.htmlAccentDark}}
html{scroll-behavior:smooth}body{font-family:'Inter',sans-serif;background:var(--bg);color:${theme.htmlText};-webkit-font-smoothing:antialiased}
.hero{background:var(--black);color:white;text-align:center;padding:72px 24px 64px;position:relative;overflow:hidden;border-bottom:1px solid var(--gray2)}
.hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 80% 60% at 50% 0%,rgba(${theme.htmlAccentRGB},0.1) 0%,transparent 70%);pointer-events:none}
.hero-chip{display:inline-flex;align-items:center;gap:6px;background:rgba(${theme.htmlAccentRGB},0.15);border:1px solid rgba(${theme.htmlAccentRGB},0.3);border-radius:100px;padding:6px 16px;font-size:12px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:var(--red);margin-bottom:28px}
.hero h1{font-family:'Bebas Neue',sans-serif;font-size:clamp(40px,8vw,64px);line-height:1;letter-spacing:1px;margin-bottom:16px}
.hero h1 span{color:var(--red)}.hero p{font-size:15px;color:rgba(255,255,255,0.6);max-width:520px;margin:0 auto;line-height:1.6}
.stats-bar{background:var(--white);border-bottom:1px solid var(--gray2);display:flex;justify-content:center}
.stat{flex:1;max-width:200px;text-align:center;padding:20px 16px;border-right:1px solid var(--gray2)}.stat:last-child{border-right:none}
.stat-num{font-size:22px;font-weight:800;letter-spacing:-0.5px;color:var(--red)}.stat-label{font-size:11px;font-weight:600;color:var(--gray3);letter-spacing:0.5px;text-transform:uppercase;margin-top:3px}
.section{max-width:1000px;margin:0 auto;padding:56px 24px}
.section-label{font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--red);margin-bottom:8px}
.section-title{font-family:'Bebas Neue',sans-serif;font-size:32px;letter-spacing:1px;margin-bottom:32px}
.packages-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}
.pkg-card{background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:22px;display:flex;flex-direction:column;gap:12px;transition:border-color 0.2s,transform 0.2s}
.pkg-card:hover{border-color:var(--red);transform:translateY(-3px)}
.pkg-badge{display:inline-block;align-self:flex-start;font-size:10px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase;color:#43ff8c;background:rgba(67,255,140,0.1);border:1px solid rgba(67,255,140,0.45);border-radius:4px;padding:5px 10px;text-shadow:0 0 6px rgba(67,255,140,0.65);box-shadow:0 0 10px rgba(67,255,140,0.22)}
.pkg-name{font-size:16px;font-weight:700;color:#fff;line-height:1.3}.pkg-desc{font-size:12px;color:var(--gray4);line-height:1.5}
.pkg-img{border-radius:8px;overflow:hidden}.pkg-img img{width:100%;height:180px;object-fit:cover;display:block}
.pkg-divider{height:1px;background:var(--gray2)}
.pkg-price{font-family:'Bebas Neue',sans-serif;font-size:28px;color:#fff;letter-spacing:1px}
.pkg-price small{font-family:'Inter',sans-serif;font-size:12px;font-weight:500;color:var(--gray4);letter-spacing:0}
.pkg-btn{margin-top:4px;width:100%;padding:12px;background:transparent;border:1px solid var(--red);color:var(--red);font-size:13px;font-weight:700;border-radius:6px;cursor:pointer;letter-spacing:1px;text-transform:uppercase;transition:all 0.2s}
.pkg-btn:hover{background:var(--red);color:white}
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(5,5,5,0.85);backdrop-filter:blur(8px);z-index:1000;align-items:center;justify-content:center;padding:24px}
.modal-overlay.active{display:flex}
.modal{background:var(--white);border:1px solid var(--red);border-radius:12px;padding:36px 32px 32px;max-width:440px;width:100%;box-shadow:0 20px 50px rgba(${theme.htmlAccentRGB},0.15);animation:popIn 0.25s cubic-bezier(0.34,1.56,0.64,1) both;text-align:center}
@keyframes popIn{from{opacity:0;transform:scale(0.95) translateY(10px)}to{opacity:1;transform:scale(1) translateY(0)}}
.modal-icon{font-size:32px;margin-bottom:12px}.modal-title{font-family:'Bebas Neue',sans-serif;font-size:28px;letter-spacing:1px;margin-bottom:16px;color:var(--red)}
.modal-pkg-name{font-size:16px;font-weight:700;color:#fff;margin-bottom:16px;display:block}
.modal-preview{background:var(--bg);border:1px solid var(--gray2);border-radius:8px;padding:14px 16px;font-size:13px;color:#fff;line-height:1.6;text-align:left;margin-bottom:24px;font-family:monospace}
.modal-preview strong{font-family:'Inter',sans-serif;font-weight:700;display:block;margin-bottom:6px;color:var(--gray4);font-size:10px;letter-spacing:1px;text-transform:uppercase}
.modal-btn-wa{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:14px;background:var(--red);color:white;font-size:14px;font-weight:700;border:none;border-radius:8px;cursor:pointer;text-decoration:none;transition:background 0.2s;letter-spacing:0.5px;margin-bottom:12px}
.modal-btn-wa:hover{background:var(--red-dark)}.modal-btn-cancel{width:100%;padding:12px;background:none;border:1px solid var(--gray2);border-radius:8px;font-size:13px;font-weight:600;color:var(--gray3);cursor:pointer}
footer{text-align:center;padding:40px 24px;font-size:12px;color:var(--gray3);border-top:1px solid var(--gray2);margin-top:40px}
@media(max-width:600px){.stats-bar{flex-wrap:wrap}.stat{min-width:50%;border-bottom:1px solid var(--gray2)}.packages-grid{grid-template-columns:1fr}.modal{padding:28px 20px 24px}}
</style>
</head>
<body>
<div class="modal-overlay" id="modalOverlay">
  <div class="modal">
    <div class="modal-icon">🛒</div>
    <div class="modal-title">SOLICITAR PRODUCTO</div>
    <span class="modal-pkg-name" id="modalPkgName"></span>
    <div class="modal-preview"><strong>MENSAJE QUE SE ENVIARÁ</strong><span id="modalMsgPreview"></span></div>
    <a class="modal-btn-wa" id="modalWaBtn" href="#" target="_blank" onclick="closeModal()">${escHtml(waBtn)}</a>
    <button class="modal-btn-cancel" onclick="closeModal()">Cancelar</button>
  </div>
</div>
<section class="hero">
  <div class="hero-chip">${escHtml(chip)}</div>
  <h1><span>${escHtml(titleRed)}</span> ${escHtml(titleRest)}</h1>
  <p>${escHtml(desc)}</p>
</section>
<div class="stats-bar">${statsHTML}</div>
<div class="section">
  <div class="section-label">${escHtml(secLabel)}</div>
  <div class="section-title">${escHtml(secTitle)}</div>
  <div class="packages-grid">${productsHTML}</div>
</div>
<footer><p>${escHtml(footer)}</p></footer>
<script>
const waNum='${waNum}';
function openModal(p,pr){
  document.getElementById('modalPkgName').innerText=p+' — '+pr;
  const msg='Hola, me interesa: '+p+' | Precio: '+pr;
  document.getElementById('modalMsgPreview').innerText=msg;
  document.getElementById('modalWaBtn').href='https://wa.me/'+waNum+'?text='+encodeURIComponent(msg);
  document.getElementById('modalOverlay').classList.add('active');
}
function closeModal(){document.getElementById('modalOverlay').classList.remove('active')}
document.querySelectorAll('.pkg-btn').forEach(b=>b.addEventListener('click',function(){openModal(this.dataset.producto,this.dataset.precio)}));
document.getElementById('modalOverlay').addEventListener('click',function(e){if(e.target===this)closeModal()});
<\/script>
</body></html>`;
}

function downloadHTML() {
  if (!STATE.articles.length) { showToast('Agrega al menos un artículo', 'err'); return; }
  const blob = new Blob([buildCatalogHTML()], { type: 'text/html;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = 'mnlatam_catalogo_2026.html';
  a.click(); URL.revokeObjectURL(url);
  showToast('✓ HTML descargado', 'ok');
}

/* ══════════════════════════════════════════
   VISTA PREVIA
══════════════════════════════════════════ */
function showPreview() {
  if (!STATE.articles.length) { showToast('Agrega artículos primero', 'err'); return; }
  document.getElementById('preview-frame').srcdoc = buildCatalogHTML();
  document.getElementById('modal-preview').classList.remove('hidden');
}

/* ══════════════════════════════════════════
   GENERAR PDF
══════════════════════════════════════════ */
function showPdfProgress(pct, lbl) {
  document.getElementById('pdf-progress-fill').style.width = pct + '%';
  document.getElementById('pdf-progress-label').textContent = lbl;
}

/* ══════════════════════════════════════════
   LOGO — se lee de assets/logo.png en tiempo real.
   Para poner tu logo real, solo reemplaza ese archivo
   (mismo nombre) — no hace falta tocar código.
══════════════════════════════════════════ */
let _logoDataUrlCache = null; // null = sin intentar, false = falló, string = ok

async function loadLogoDataURL() {
  if (_logoDataUrlCache !== null) return _logoDataUrlCache;
  try {
    const resp = await fetch('assets/logo.png', { cache: 'no-store' });
    if (!resp.ok) { _logoDataUrlCache = false; return false; }
    const blob = await resp.blob();
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
    _logoDataUrlCache = dataUrl;
    return dataUrl;
  } catch (err) {
    console.error('No se pudo cargar assets/logo.png', err);
    _logoDataUrlCache = false;
    return false;
  }
}

/* ══════════════════════════════════════════
   IMÁGENES EN PDF SIN DEFORMAR
   Antes se estiraban al tamaño exacto de la caja
   (jsPDF no recorta como object-fit:cover). Ahora se
   calculan las proporciones reales y se centra la foto
   dentro de su caja, como una miniatura "contain".
══════════════════════════════════════════ */
async function getImgDims(src) {
  return new Promise(resolve => {
    const img = new Image();
    img.onload  = () => resolve({ w: img.naturalWidth, h: img.naturalHeight });
    img.onerror = () => resolve({ w: 4, h: 3 });
    img.src = src;
  });
}

async function pdfAddImageFit(pdf, src, x, y, maxW, maxH, cache) {
  const { w, h } = (cache && cache.has(src)) ? cache.get(src) : await getImgDims(src);
  if (!w || !h) return;
  const ratio = w / h;
  let iW = maxW, iH = iW / ratio;
  if (iH > maxH) { iH = maxH; iW = iH * ratio; }
  const ox = x + (maxW - iW) / 2;
  const oy = y + (maxH - iH) / 2;
  const fmt = src.startsWith('data:image/png') ? 'PNG'
            : src.startsWith('data:image/webp') ? 'WEBP' : 'JPEG';
  try { pdf.addImage(src, fmt, ox, oy, iW, iH, '', 'MEDIUM'); } catch (_) {}
}

/* ══════════════════════════════════════════
   IMPORTAR ARTÍCULOS DESDE UN PDF
   Pensado para PDFs generados por esta misma app (o una
   versión anterior con el mismo diseño de 1 artículo por
   hoja). Se lee el texto de cada hoja para sacar nombre y
   precio, y se recorta la región de la imagen usando la
   posición REAL donde jsPDF dibujó el precio — así no
   importa si el nombre o la descripción ocuparon 1 o
   varias líneas, siempre se encuentra la imagen correcta.
══════════════════════════════════════════ */
const PT_PER_MM = 72 / 25.4;

const PDFJS_VERSION = '5.6.205';
let _pdfjsLoadingPromise = null;

async function ensurePdfJsLoaded() {
  if (window.pdfjsLib) return true;
  if (!_pdfjsLoadingPromise) {
    _pdfjsLoadingPromise = (async () => {
      try {
        const pdfjsLib = await import(`https://cdn.jsdelivr.net/npm/pdfjs-dist@${PDFJS_VERSION}/build/pdf.min.mjs`);
        pdfjsLib.GlobalWorkerOptions.workerSrc =
          `https://cdn.jsdelivr.net/npm/pdfjs-dist@${PDFJS_VERSION}/build/pdf.worker.min.mjs`;
        window.pdfjsLib = pdfjsLib;
        return true;
      } catch (err) {
        console.error('No se pudo cargar PDF.js', err);
        return false;
      }
    })();
  }
  return _pdfjsLoadingPromise;
}

/* Reconstruye "líneas visuales" a partir de los fragmentos de texto
   del PDF, agrupando por posición Y (independiente del orden interno
   del PDF), y guarda el tamaño de letra de cada línea para poder
   distinguir nombre (grande) de descripción (chica). */
function groupTextIntoLines(textContent) {
  const items = textContent.items
    .filter(it => it.str && it.str.trim())
    .map(it => ({
      str: it.str, x: it.transform[4], y: it.transform[5],
      size: Math.abs(it.transform[3]) || Math.abs(it.transform[0]) || 1,
    }));
  items.sort((a, b) => b.y - a.y || a.x - b.x);

  const lines = [];
  let current = [], lineY = null;
  const TOL = 2;
  for (const it of items) {
    if (lineY === null || Math.abs(it.y - lineY) <= TOL) {
      current.push(it);
      if (lineY === null) lineY = it.y;
    } else {
      lines.push(current);
      current = [it];
      lineY = it.y;
    }
  }
  if (current.length) lines.push(current);

  return lines.map(line => {
    const sorted = line.slice().sort((a, b) => a.x - b.x);
    return {
      text: sorted.map(it => it.str).join(' ').replace(/\s+/g, ' ').trim(),
      y: line[0].y,
      size: Math.max(...line.map(it => it.size)),
    };
  }).filter(l => l.text);
}

/* Interpreta las líneas de una hoja. Devuelve null si la hoja no
   parece ser un artículo (por ejemplo, la portada del catálogo). */
function parseArticlePageLines(lines) {
  if (lines.length < 2) return null;
  const body = lines.slice(1); // línea 0 = encabezado marca + paginación

  let badge = null, idx = 0;
  const bm = body[0] && body[0].text.match(/^([A-ZÁÉÍÓÚÑ][A-ZÁÉÍÓÚÑ /]*?)\s+(\d{2})$/);
  if (bm) { badge = bm[1].trim(); idx = 1; }

  let sinImagen = false;
  const contentLines = [];
  for (let i = idx; i < body.length; i++) {
    const t = body[i].text;
    if (/derechos reservados/i.test(t)) continue;
    if (/^Sin imagen$/i.test(t)) { sinImagen = true; continue; }
    contentLines.push(body[i]);
  }

  let priceIdx = -1, precio = '', moneda = 'MXN', consultar = false, priceLine = null;
  for (let i = contentLines.length - 1; i >= 0; i--) {
    const t = contentLines[i].text;
    if (/consultar precio/i.test(t)) { priceIdx = i; consultar = true; priceLine = contentLines[i]; break; }
    const m = t.match(/\$?\s*([\d,]+(?:\.\d+)?)\s*([A-Z]{3})?\s*$/);
    if (m && /\d/.test(m[1])) {
      priceIdx = i; precio = m[1].replace(/,/g, ''); if (m[2]) moneda = m[2];
      priceLine = contentLines[i]; break;
    }
  }
  if (priceIdx === -1) return null; // no parece una hoja de artículo

  const preLines = contentLines.slice(0, priceIdx);
  let nombre = '', descripcion = '';
  if (preLines.length <= 1) {
    nombre = preLines.map(l => l.text).join(' ').trim();
  } else {
    const maxSize = Math.max(...preLines.map(l => l.size));
    nombre      = preLines.filter(l => l.size >= maxSize - 2).map(l => l.text).join(' ').trim();
    descripcion = preLines.filter(l => l.size <  maxSize - 2).map(l => l.text).join(' ').trim();
  }

  return {
    badge: badge || 'DISPONIBLE', nombre: nombre || 'Artículo',
    precio, moneda, descripcion, sinImagen, consultar,
    priceLineY: priceLine.y,
  };
}

/* Recorta del renderizado de la hoja exactamente la región donde
   debería estar la imagen, usando la posición real del precio como
   ancla (misma aritmética que generatePDF: +12/+10, +2 del divisor,
   +5 del margen). */
/* Si la foto original no llenaba toda su caja (se ajustó sin
   deformar), quedan franjas del fondo gris oscuro de la tarjeta.
   Esto las recorta para dejar solo la foto real. */
function trimBackgroundPadding(canvas, bgColor, tolerance = 14) {
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  if (w < 20 || h < 20) return canvas;
  const data = ctx.getImageData(0, 0, w, h).data;

  const isBg = (x, y) => {
    const idx = (y * w + x) * 4;
    return Math.abs(data[idx] - bgColor[0]) <= tolerance &&
           Math.abs(data[idx + 1] - bgColor[1]) <= tolerance &&
           Math.abs(data[idx + 2] - bgColor[2]) <= tolerance;
  };
  const rowIsBg = y => { let n = 0, total = 0; for (let x = 0; x < w; x += 4) { total++; if (isBg(x, y)) n++; } return n > total * 0.92; };
  const colIsBg = x => { let n = 0, total = 0; for (let y = 0; y < h; y += 4) { total++; if (isBg(x, y)) n++; } return n > total * 0.92; };

  let top = 0, bottom = h - 1, left = 0, right = w - 1;
  while (top < bottom - 10 && rowIsBg(top)) top++;
  while (bottom > top + 10 && rowIsBg(bottom)) bottom--;
  while (left < right - 10 && colIsBg(left)) left++;
  while (right > left + 10 && colIsBg(right)) right--;

  if (top === 0 && bottom === h - 1 && left === 0 && right === w - 1) return canvas;

  const trimmed = document.createElement('canvas');
  trimmed.width = right - left + 1;
  trimmed.height = bottom - top + 1;
  trimmed.getContext('2d').drawImage(canvas, left, top, trimmed.width, trimmed.height, 0, 0, trimmed.width, trimmed.height);
  return trimmed;
}

async function cropArticleImage(pdfPage, priceLineY, consultar) {
  const preCy    = 297 - (priceLineY / PT_PER_MM);
  const imgAreaY = preCy + (consultar ? 10 : 12) + 2 + 5;
  const footerY  = 297 - 13;
  const imgBottom= footerY - 3;
  const IX = 8, IW = 210 - IX - 12;
  if (imgBottom - imgAreaY < 15) return null;

  const scale = 3;
  const viewport = pdfPage.getViewport({ scale });
  const canvas = document.createElement('canvas');
  canvas.width = viewport.width; canvas.height = viewport.height;
  await pdfPage.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;

  const pxPerMm = viewport.width / 210;
  const sx = IX * pxPerMm, sy = imgAreaY * pxPerMm;
  const sw = IW * pxPerMm, sh = (imgBottom - imgAreaY) * pxPerMm;
  if (sw < 10 || sh < 10) return null;

  const out = document.createElement('canvas');
  out.width = Math.round(sw); out.height = Math.round(sh);
  out.getContext('2d').drawImage(canvas, sx, sy, sw, sh, 0, 0, sw, sh);

  const trimmed = trimBackgroundPadding(out, [42, 42, 42]);
  return trimmed.toDataURL('image/jpeg', 0.9);
}

async function importFromPDF(file) {
  const ok = await ensurePdfJsLoaded();
  if (!ok) { showToast('No se pudo cargar el lector de PDF. Revisa tu conexión.', 'err', 4000); return; }

  document.getElementById('modal-pdf-title').textContent = 'IMPORTANDO PDF…';
  document.getElementById('modal-pdf-progress').classList.remove('hidden');
  showPdfProgress(0, 'Abriendo archivo…');

  try {
    const buf = await file.arrayBuffer();
    const pdfDoc = await window.pdfjsLib.getDocument({ data: buf }).promise;
    const numPages = pdfDoc.numPages;

    let added = 0, withImg = 0;

    for (let p = 1; p <= numPages; p++) {
      showPdfProgress(5 + (p / numPages) * 90, `Página ${p} de ${numPages}…`);

      const page = await pdfDoc.getPage(p);
      const textContent = await page.getTextContent();
      const lines  = groupTextIntoLines(textContent);
      const parsed = parseArticlePageLines(lines);
      if (!parsed) continue;

      let imgSrc = null;
      if (!parsed.sinImagen) {
        try { imgSrc = await cropArticleImage(page, parsed.priceLineY, parsed.consultar); }
        catch (err) { console.error('No se pudo recortar la imagen de la página', p, err); imgSrc = null; }
      }

      await addArticle({
        nombre: parsed.nombre, precio: parsed.precio, moneda: parsed.moneda,
        badge: parsed.badge, descripcion: parsed.descripcion, imgSrc,
      });

      if (imgSrc) {
        const photo = { id: uidPhoto(), name: `${parsed.nombre} — pág. ${p}`, src: imgSrc };
        STATE.photos.push(photo);
        await dbPut(ST_PHO, photo);
        withImg++;
      }
      added++;
    }

    renderPhotosGrid();
    showPdfProgress(100, 'Listo'); await sleep(250);
    document.getElementById('modal-pdf-progress').classList.add('hidden');

    if (added === 0) {
      showToast('No se reconoció ningún artículo en ese PDF', 'err', 4000);
    } else {
      showToast(`✓ ${added} artículo(s) importado(s)${withImg ? ` · ${withImg} con foto` : ''}`, 'ok', 4200);
    }
  } catch (err) {
    console.error(err);
    document.getElementById('modal-pdf-progress').classList.add('hidden');
    showToast('Error al leer el PDF: ' + err.message, 'err', 4000);
  }
}

/* ══════════════════════════════════════════
   ASIGNACIÓN AUTOMÁTICA DE FOTOS CON IA
   (Google Gemini 2.5 Flash — multimodal)

   Toma los artículos que aún NO tienen foto y las fotos
   de la galería que aún NO se usan en ningún artículo,
   las manda en una sola llamada a la API (nombres + fotos
   reducidas de tamaño) y le pide de vuelta un JSON con las
   parejas artículo↔foto que tengan buena relación visual.

   La clave de la API vive SOLO en este dispositivo — se
   guarda como cualquier otro campo del panel de config
   (IndexedDB, cfg-gemini-key). Nunca queda escrita en este
   archivo ni se sube a ningún lado; por eso el input es de
   tipo "password" y por eso esta función siempre la lee en
   el momento con getCfg('cfg-gemini-key') en vez de tenerla
   fija en el código.

   SOBRE EL MODELO: Google retira modelos de Gemini seguido (a
   veces incluso antes de la fecha de apagado que ellos mismos
   anuncian). Si GEMINI_MODEL deja de responder (error 404 = "este
   modelo ya no existe"), la función de abajo NO se rinde: le
   pregunta a la API cuáles modelos "flash" siguen vigentes para
   esa clave (discoverWorkingGeminiModel) y reintenta con el que
   encuentre, actualizando GEMINI_MODEL para el resto de la sesión.
══════════════════════════════════════════ */
let GEMINI_MODEL = 'gemini-3.7-flash'; // vigente a agosto 2026 — si cambia, se autocorrige solo (ver arriba)

/* Le pregunta a la API qué modelos están disponibles AHORA MISMO
   para esta clave, y devuelve el nombre de un modelo "flash" que
   sí soporte generateContent (evitando los de imagen/audio/tts).
   Se usa solo como respaldo cuando GEMINI_MODEL da 404. */
async function discoverWorkingGeminiModel(apiKey) {
  const resp = await fetch('https://generativelanguage.googleapis.com/v1beta/models', {
    headers: { 'x-goog-api-key': apiKey },
  });
  if (!resp.ok) return null;
  const data = await resp.json();
  const models = Array.isArray(data.models) ? data.models : [];
  const usables = models.filter(m =>
    Array.isArray(m.supportedGenerationMethods) &&
    m.supportedGenerationMethods.includes('generateContent') &&
    /flash/i.test(m.name) &&
    !/image|tts|audio|embedding|live/i.test(m.name)
  );
  if (!usables.length) return null;
  // preferir versión "estable" (sin -preview/-exp/-latest) y, entre esas, el nombre más alto
  usables.sort((a, b) => {
    const aStable = /preview|exp|latest/i.test(a.name) ? 0 : 1;
    const bStable = /preview|exp|latest/i.test(b.name) ? 0 : 1;
    if (aStable !== bStable) return bStable - aStable;
    return b.name.localeCompare(a.name, undefined, { numeric: true });
  });
  return usables[0].name.replace(/^models\//, '');
}

/* Pide la clave de Gemini AHÍ MISMO, en un modal dentro de la
   app, en vez de mandar al usuario a buscar el panel de config.
   Al guardar, la clave queda en cfg-gemini-key (IndexedDB, igual
   que cualquier otro campo) Y sigue directo con el reconocimiento,
   sin que el usuario tenga que volver a tocar el botón. */
function abrirPedirClaveIA() {
  const input = document.getElementById('ai-key-input');
  input.value = '';
  document.getElementById('modal-ai-key').classList.remove('hidden');
  setTimeout(() => input.focus(), 60);
}
function cerrarPedirClaveIA() {
  document.getElementById('modal-ai-key').classList.add('hidden');
}
document.getElementById('btn-ai-key-cancel').addEventListener('click', cerrarPedirClaveIA);
document.getElementById('modal-ai-key').addEventListener('click', e => {
  if (e.target.id === 'modal-ai-key') cerrarPedirClaveIA();
});
async function guardarClaveIAYContinuar() {
  const val = document.getElementById('ai-key-input').value.trim();
  if (!val) { showToast('Pega tu clave primero', 'err'); return; }
  document.getElementById('cfg-gemini-key').value = val;
  await dbPut(ST_CFG, { key: 'cfg-gemini-key', val });
  cerrarPedirClaveIA();
  autoAssignPhotosWithAI();
}
document.getElementById('btn-ai-key-save').addEventListener('click', guardarClaveIAYContinuar);
document.getElementById('ai-key-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') guardarClaveIAYContinuar();
});

/* Reduce una foto (dataURL) a un JPEG chico antes de mandarla
   a la IA — así la llamada es rápida y ligera aunque la galería
   tenga fotos de varios MB tomadas con el celular. */
function downscaleImageForAI(dataUrl, maxDim = 768, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let w = img.naturalWidth, h = img.naturalHeight;
      if (!w || !h) { reject(new Error('Foto inválida')); return; }
      if (w > maxDim || h > maxDim) {
        const ratio = Math.min(maxDim / w, maxDim / h);
        w = Math.max(1, Math.round(w * ratio));
        h = Math.max(1, Math.round(h * ratio));
      }
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      canvas.getContext('2d').drawImage(img, 0, 0, w, h);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => reject(new Error('No se pudo leer una foto'));
    img.src = dataUrl;
  });
}

const GEMINI_BATCH_SIZE  = 10; // fotos por llamada. Google recomienda no pasar de ~14 imágenes
                                // en un solo prompt; mandar 170 de golpe en una sola llamada es
                                // justo lo que provoca el error 503 ("modelo saturado") o que la
                                // solicitud se tarde tanto que el servidor la corte.
const GEMINI_MAX_RETRIES = 4;  // reintentos con backoff exponencial ante 503/429 — es la falla
                                // TEMPORAL del servidor de Google, no un error de esta app ni de
                                // tu clave; casi siempre se resuelve esperando unos segundos.

/* Llama a generateContent con reintentos automáticos (1s, 2s, 4s, 8s
   + variación al azar). Un 503 ("The model is overloaded") o 429
   (límite de uso) casi siempre se resuelve solo esperando un poco —
   es el comportamiento oficialmente recomendado por Google para
   estos dos códigos. Si tras todos los intentos sigue fallando,
   devuelve la respuesta (o null) para que quien llama decida. */
async function callGeminiWithRetry(apiKey, modelo, requestBody, onRetryNote) {
  for (let intento = 0; intento <= GEMINI_MAX_RETRIES; intento++) {
    let resp;
    try {
      resp = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${modelo}:generateContent`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
          body: JSON.stringify(requestBody),
        }
      );
    } catch (e) {
      resp = null; // error de red (sin conexión, etc.)
    }

    if (resp && resp.ok) return resp;

    const status = resp ? resp.status : 0;
    const esTemporal = status === 503 || status === 429 || status === 0;
    if (!esTemporal || intento === GEMINI_MAX_RETRIES) return resp;

    const espera = Math.min(8000, 1000 * (2 ** intento)) + Math.random() * 400;
    if (onRetryNote) onRetryNote(status, intento + 1, espera);
    await sleep(espera);
  }
}

async function autoAssignPhotosWithAI() {
  const apiKey = getCfg('cfg-gemini-key');
  if (!apiKey) {
    showToast('Falta tu clave de Gemini', 'err', 3500);
    return;
  }

  let articulosPendientes = STATE.articles.filter(a => !a.imgSrc);
  const fotosEnUso   = new Set(STATE.articles.filter(a => a.imgSrc).map(a => a.imgSrc));
  const fotosSinUsar = STATE.photos.filter(p => !fotosEnUso.has(p.src));

  if (!articulosPendientes.length) { showToast('Todos tus artículos ya tienen foto asignada', 'err', 3500); return; }
  if (!fotosSinUsar.length)        { showToast('No hay fotos sin usar en la galería. Sube fotos primero.', 'err', 3500); return; }

  document.getElementById('modal-pdf-title').textContent = 'ASIGNANDO FOTOS CON IA…';
  document.getElementById('modal-pdf-progress').classList.remove('hidden');

  const totalLotes = Math.ceil(fotosSinUsar.length / GEMINI_BATCH_SIZE);
  let totalAplicadas = 0;
  let lotesConError  = 0;

  try {
    for (let lote = 0; lote < totalLotes; lote++) {
      if (!articulosPendientes.length) break; // ya no queda ningún artículo por asignar

      const fotosLote = fotosSinUsar.slice(lote * GEMINI_BATCH_SIZE, (lote + 1) * GEMINI_BATCH_SIZE);
      const pctBase = (lote / totalLotes) * 100;
      const pctSpan = 100 / totalLotes;

      showPdfProgress(pctBase, `Lote ${lote + 1} de ${totalLotes} — preparando ${fotosLote.length} foto(s)…`);

      // 1. Reducir de tamaño SOLO las fotos de este lote (no las 170 de golpe)
      const partesFotos = [];
      for (const photo of fotosLote) {
        try {
          const small = await downscaleImageForAI(photo.src);
          partesFotos.push({ text: `FOTO ID: ${photo.id}` });
          partesFotos.push({ inline_data: { mime_type: 'image/jpeg', data: small.split(',')[1] } });
        } catch (e) { /* esa foto puntual se salta, sigue con las demás del lote */ }
      }
      if (!partesFotos.length) { lotesConError++; continue; }

      // 2. Prompt con los artículos que TODAVÍA faltan (la lista se va
      //    achicando lote a lote conforme se van resolviendo)
      const listaArticulos = articulosPendientes
        .map((a, i) => `${i}: ${a.nombre || 'Artículo sin nombre'}`)
        .join('\n');

      const instruccion = `Eres un asistente que empareja fotos de productos con artículos de un catálogo.
Te doy una lista numerada de artículos (ARTÍCULOS) y varias fotos, cada una precedida por un texto "FOTO ID: <id>".
Para cada foto, decide a qué artículo de la lista corresponde según lo que se ve en la imagen y el nombre del artículo.
Incluye una asignación SOLO cuando la relación sea razonablemente clara. Si una foto no corresponde con
confianza a ningún artículo de la lista, no la incluyas en la respuesta — es mejor dejarla sin asignar que adivinar mal.
Cada foto se usa como máximo una vez y cada artículo recibe como máximo una foto.

ARTÍCULOS:
${listaArticulos}`;

      const requestBody = {
        contents: [{ role: 'user', parts: [{ text: instruccion }, ...partesFotos] }],
        generationConfig: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: 'OBJECT',
            properties: {
              asignaciones: {
                type: 'ARRAY',
                items: {
                  type: 'OBJECT',
                  properties: {
                    articulo_index: { type: 'INTEGER', description: 'índice del artículo en la lista ARTÍCULOS' },
                    foto_id:        { type: 'STRING',  description: 'el FOTO ID exacto de la imagen elegida' },
                  },
                  required: ['articulo_index', 'foto_id'],
                },
              },
            },
            required: ['asignaciones'],
          },
        },
      };

      showPdfProgress(pctBase + pctSpan * 0.3, `Lote ${lote + 1} de ${totalLotes} — consultando IA…`);

      let resp = await callGeminiWithRetry(apiKey, GEMINI_MODEL, requestBody, (status, intento, espera) => {
        showPdfProgress(
          pctBase + pctSpan * 0.3,
          `Lote ${lote + 1} de ${totalLotes} — servidor de Gemini saturado (${status}), reintentando en ${Math.round(espera / 1000)}s (intento ${intento}/${GEMINI_MAX_RETRIES})…`
        );
      });

      // 404 = ese modelo ya no existe (Google los retira seguido). Se busca
      // uno "flash" vigente para esta clave y se reintenta este lote una vez.
      if (resp && resp.status === 404) {
        showPdfProgress(pctBase + pctSpan * 0.5, `"${GEMINI_MODEL}" ya no está disponible, buscando un modelo vigente…`);
        const alterno = await discoverWorkingGeminiModel(apiKey).catch(() => null);
        if (alterno && alterno !== GEMINI_MODEL) {
          GEMINI_MODEL = alterno; // se recuerda para el resto de la sesión
          resp = await callGeminiWithRetry(apiKey, alterno, requestBody, () => {});
        }
      }

      if (!resp || !resp.ok) {
        if (resp) { try { console.error('Gemini error', resp.status, await resp.text()); } catch (_) {} }
        lotesConError++;
        continue; // no se pierde lo ya avanzado — sigue con el siguiente lote
      }

      showPdfProgress(pctBase + pctSpan * 0.8, `Lote ${lote + 1} de ${totalLotes} — leyendo resultado…`);

      let asignaciones = [];
      try {
        const data = await resp.json();
        const rawText = (data?.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('');
        const parsed = JSON.parse(rawText);
        asignaciones = Array.isArray(parsed?.asignaciones) ? parsed.asignaciones : [];
      } catch (e) { lotesConError++; continue; }

      // 3. Aplicar asignaciones de este lote — nunca repetir artículo ni foto
      const usedIdx = new Set(), usedFotoIds = new Set();
      for (const asign of asignaciones) {
        const idx = asign?.articulo_index, fotoId = asign?.foto_id;
        if (typeof idx !== 'number' || !fotoId) continue;
        if (usedIdx.has(idx) || usedFotoIds.has(fotoId)) continue;
        const articulo = articulosPendientes[idx];
        const foto = fotosLote.find(p => p.id === fotoId);
        if (!articulo || !foto) continue;

        usedIdx.add(idx); usedFotoIds.add(fotoId);
        await updateField(articulo.id, 'imgSrc', foto.src);
        const card = document.querySelector(`.article-card[data-id="${articulo.id}"]`);
        if (card) applyImg(card, articulo.id, foto.src);
        totalAplicadas++;
      }

      // los ya resueltos salen del pool para que el siguiente lote no los repita
      articulosPendientes = articulosPendientes.filter(a => !a.imgSrc);
      renderPhotosGrid();

      if (lote < totalLotes - 1) await sleep(500); // pausa breve entre lotes, evita ráfagas
    }

    showPdfProgress(100, 'Listo'); await sleep(250);
    document.getElementById('modal-pdf-progress').classList.add('hidden');

    const sinAsignar = articulosPendientes.length;

    if (totalAplicadas === 0 && lotesConError === totalLotes) {
      showToast('No se pudo conectar con la IA — el servidor de Gemini está saturado ahora mismo. Espera un momento y toca el botón de nuevo.', 'err', 5800);
    } else {
      let msg = `✓ ${totalAplicadas} foto${totalAplicadas === 1 ? '' : 's'} asignada${totalAplicadas === 1 ? '' : 's'} con IA`;
      if (sinAsignar) msg += ` · ${sinAsignar} artículo(s) sin coincidencia`;
      if (lotesConError) msg += ` · ${lotesConError} lote(s) fallaron por saturación del servidor — toca el botón otra vez para completar lo que falta`;
      showToast(msg, (lotesConError && totalAplicadas === 0) ? 'err' : 'ok', 6200);
    }
  } catch (err) {
    console.error(err);
    document.getElementById('modal-pdf-progress').classList.add('hidden');
    showToast(err.message || 'Error al asignar fotos con IA', 'err', 4800);
  }
}

/* ══════════════════════════════════════════
   LISTA DE PRECIOS — PDF simple sin imágenes
   Solo nombre + precio, para compartir rápido por
   WhatsApp cuando no hace falta el catálogo completo.
══════════════════════════════════════════ */
function exportPriceListPDF() {
  if (!STATE.articles.length) { showToast('Agrega artículos primero', 'err'); return; }

  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const W = 210, H = 297, M = 16;
  const theme = getActiveTheme();
  const RED = theme.lightAccent, TXT = [30, 30, 30], GR3 = [130, 130, 130], GR2 = [222, 222, 222];

  const titleRed  = getCfg('cfg-title-red')  || 'MN';
  const titleRest = getCfg('cfg-title-rest') || 'LATAM';
  const footer    = getCfg('cfg-footer');

  let y = M;
  pdf.setFont('helvetica', 'bold'); pdf.setFontSize(22);
  pdf.setTextColor(...RED); pdf.text(titleRed.toUpperCase(), M, y + 8);
  const rw = pdf.getTextWidth(titleRed.toUpperCase());
  pdf.setTextColor(...TXT); pdf.text(' ' + titleRest.toUpperCase(), M + rw, y + 8);
  pdf.setFont('helvetica', 'normal'); pdf.setFontSize(10); pdf.setTextColor(...GR3);
  pdf.text('LISTA DE PRECIOS', M, y + 15);
  pdf.setDrawColor(...RED); pdf.setLineWidth(0.6); pdf.line(M, y + 19, W - M, y + 19);
  y += 30;

  const items = STATE.articles.slice().sort((a,b) => (a.orden||0) - (b.orden||0));
  pdf.setFontSize(11);

  items.forEach((art, i) => {
    if (y > H - 25) { pdf.addPage(); y = M; }

    const nombre    = art.nombre || 'Artículo';
    const precioTxt = art.precio ? '$' + formatPrecio(art.precio) + ' ' + (art.moneda || 'MXN') : 'Consultar';

    pdf.setFont('helvetica', 'normal'); pdf.setTextColor(...TXT);
    const nameLines = pdf.splitTextToSize(nombre, W - M*2 - 45);
    pdf.text(nameLines, M, y);

    pdf.setFont('helvetica', 'bold'); pdf.setTextColor(...RED);
    pdf.text(precioTxt, W - M, y, { align: 'right' });

    y += Math.max(nameLines.length * 5.5, 7);
    if (i < items.length - 1) {
      pdf.setDrawColor(...GR2); pdf.setLineWidth(0.2);
      pdf.line(M, y, W - M, y);
    }
    y += 6;
  });

  if (footer) {
    pdf.setFont('helvetica', 'normal'); pdf.setFontSize(8); pdf.setTextColor(...GR3);
    pdf.text(footer, W / 2, H - 10, { align: 'center' });
  }

  pdf.save((titleRed + '_' + titleRest).toLowerCase().replace(/\s+/g, '_') + '_lista_precios.pdf');
  showToast('✓ Lista de precios descargada', 'ok');
}

async function generatePDF() {
  if (!STATE.articles.length) { showToast('Agrega artículos primero', 'err'); return; }
  document.getElementById('modal-pdf-progress').classList.remove('hidden');
  showPdfProgress(0, 'Iniciando…');
  await sleep(60);

  try {
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const W = 210, H = 297, M = 12, CW = W - M * 2;
    const theme = getActiveTheme();
    const BG   = theme.pdfBg;
    const CARD = theme.pdfCard;
    const RED  = theme.pdfAccent;
    const TXT  = theme.pdfText;
    const GR2  = theme.pdfGr2;
    const GR3  = theme.pdfGr3;
    const GR4  = theme.pdfGr4;

    const chip      = getCfg('cfg-chip');
    const titleRed  = getCfg('cfg-title-red');
    const titleRest = getCfg('cfg-title-rest');
    const desc      = getCfg('cfg-desc');
    const secLabel  = getCfg('cfg-section-label');
    const secTitle  = getCfg('cfg-section-title');
    const footer    = getCfg('cfg-footer');

    const pageBg = () => { pdf.setFillColor(...BG); pdf.rect(0, 0, W, H, 'F'); };

    /* PORTADA */
    const logoDataUrl = await loadLogoDataURL();
    const OFFSET = 30; // espacio reservado por el logo, se suma a todo lo de abajo

    pageBg();
    for (let i = 0; i < 35; i++) {
      pdf.setGState(pdf.GState({ opacity: 0.07*(1-i/35) }));
      pdf.setFillColor(...RED);
      pdf.rect(0, i*3, W, 3, 'F');
    }
    pdf.setGState(pdf.GState({ opacity: 1 }));

    /* Logo cuadrado (assets/logo.png) — ideal para que se vea bien
       en la miniatura cuando se comparte el PDF por WhatsApp */
    if (logoDataUrl) {
      const logoSize = 24, logoX = W/2 - logoSize/2, logoY = 12;
      pdf.setFillColor(...CARD); pdf.roundedRect(logoX, logoY, logoSize, logoSize, 4, 4, 'F');
      await pdfAddImageFit(pdf, logoDataUrl, logoX, logoY, logoSize, logoSize);
    }

    pdf.setFillColor(...theme.pdfChipBg);
    pdf.roundedRect(M, 32+OFFSET, CW, 10, 2, 2, 'F');
    pdf.setFont('helvetica','bold'); pdf.setFontSize(8); pdf.setTextColor(...RED);
    pdf.text(chip.toUpperCase(), W/2, 38.5+OFFSET, { align:'center' });

    pdf.setFont('helvetica','bold'); pdf.setFontSize(52);
    const t1 = titleRed.toUpperCase(), t2 = titleRest.toUpperCase();
    const t1W = pdf.getTextWidth(t1), t2W = pdf.getTextWidth(t2);
    const tot = t1W + t2W + 4;
    pdf.setTextColor(...RED); pdf.text(t1, W/2 - tot/2 + t1W/2, 82+OFFSET, { align:'center' });
    pdf.setTextColor(...TXT); pdf.text(t2, W/2 + tot/2 - t2W/2, 82+OFFSET, { align:'center' });

    pdf.setDrawColor(...RED); pdf.setLineWidth(1.2); pdf.line(M, 90+OFFSET, W-M, 90+OFFSET);
    pdf.setLineWidth(0.3); pdf.line(M, 93+OFFSET, W-M, 93+OFFSET);

    pdf.setFont('helvetica','normal'); pdf.setFontSize(11); pdf.setTextColor(...GR4);
    const descL = pdf.splitTextToSize(desc, CW-20);
    pdf.text(descL, W/2, 104+OFFSET, { align:'center', lineHeightFactor:1.5 });

    const stats = Array.from(document.querySelectorAll('.stat-row')).map(r => ({
      v: r.querySelector('.stat-val')?.value||'',
      l: r.querySelector('.stat-lbl')?.value||'',
    })).filter(s => s.v||s.l);

    if (stats.length) {
      const sy = 132+OFFSET;
      pdf.setFillColor(...CARD); pdf.roundedRect(M, sy-6, CW, 22, 3, 3, 'F');
      stats.forEach((s,i) => {
        const cx = M + i*(CW/stats.length) + (CW/stats.length)/2;
        pdf.setFont('helvetica','bold'); pdf.setFontSize(16); pdf.setTextColor(...RED);
        pdf.text(s.v, cx, sy+5, { align:'center' });
        pdf.setFont('helvetica','normal'); pdf.setFontSize(7); pdf.setTextColor(...GR3);
        pdf.text(s.l.toUpperCase(), cx, sy+11, { align:'center' });
        if (i < stats.length-1) { pdf.setDrawColor(...GR2); pdf.setLineWidth(0.3); pdf.line(M+(i+1)*(CW/stats.length), sy-2, M+(i+1)*(CW/stats.length), sy+14); }
      });
    }

    pdf.setFontSize(8); pdf.setFont('helvetica','bold'); pdf.setTextColor(...RED);
    pdf.text(secLabel.toUpperCase(), M, 168+OFFSET);
    pdf.setFontSize(22); pdf.setTextColor(...TXT);
    pdf.text(secTitle.toUpperCase(), M, 180+OFFSET);
    pdf.setDrawColor(...RED); pdf.setLineWidth(0.8); pdf.line(M, 184+OFFSET, W-M, 184+OFFSET);

    pdf.setFillColor(...CARD); pdf.rect(0, H-14, W, 14, 'F');
    pdf.setFont('helvetica','normal'); pdf.setFontSize(8); pdf.setTextColor(...GR3);
    pdf.text(footer, W/2, H-5, { align:'center' });

    showPdfProgress(15, 'Portada lista…'); await sleep(40);

    /* Precargar dimensiones de imágenes para insertarlas sin deformar */
    showPdfProgress(17, 'Preparando fotos…');
    const dimsCache = new Map();
    for (const art of STATE.articles) {
      if (art.imgSrc && !dimsCache.has(art.imgSrc)) {
        dimsCache.set(art.imgSrc, await getImgDims(art.imgSrc));
      }
    }

    /* ARTÍCULOS — 1 por hoja, imagen a tamaño grande sin deformar
       (preparado para cuando un artículo tenga varias fotos: 2 lado
       a lado, 3+ en grid — por ahora imgSrc siempre da 0 o 1 foto) */
    const total = STATE.articles.length;

    for (let i = 0; i < total; i++) {
      pdf.addPage(); pageBg();

      const art    = STATE.articles[i];
      const images = art.images?.length ? art.images : (art.imgSrc ? [art.imgSrc] : []);

      pdf.setFillColor(...RED); pdf.rect(0, 0, 4, H, 'F');

      pdf.setFillColor(...CARD); pdf.rect(0, 0, W, 13, 'F');
      pdf.setFont('helvetica','bold'); pdf.setFontSize(7); pdf.setTextColor(...RED);
      pdf.text((titleRed+' '+titleRest).toUpperCase(), 8, 8.5);
      pdf.setTextColor(...GR3); pdf.setFont('helvetica','normal');
      pdf.text(`${i+2} / ${total+1}`, W-M, 8.5, { align:'right' });
      pdf.setDrawColor(...RED); pdf.setLineWidth(0.6); pdf.line(0, 13, W, 13);

      let cy = 20;

      const badge = (art.badge||'DISPONIBLE').toUpperCase();
      pdf.setFont('helvetica','bold'); pdf.setFontSize(6.5); pdf.setTextColor(...GR4);
      pdf.setFillColor(...GR2);
      const bW = pdf.getTextWidth(badge) + 10;
      pdf.roundedRect(8, cy-3.5, bW, 6.5, 1, 1, 'F');
      pdf.text(badge, 13, cy+0.5);
      pdf.setFontSize(10); pdf.setTextColor(...RED);
      pdf.text(String(i+1).padStart(2,'0'), W-M, cy+0.5, { align:'right' });
      cy += 9;

      pdf.setFont('helvetica','bold'); pdf.setFontSize(18); pdf.setTextColor(...TXT);
      const nameL = pdf.splitTextToSize(art.nombre||'Artículo', CW-10);
      pdf.text(nameL, 8, cy);
      cy += nameL.length * 8 + 3;

      if (art.descripcion) {
        pdf.setFont('helvetica','normal'); pdf.setFontSize(9); pdf.setTextColor(...GR3);
        const dL = pdf.splitTextToSize(art.descripcion, CW-10).slice(0,3);
        pdf.text(dL, 8, cy);
        cy += dL.length * 5 + 3;
      }

      if (art.precio) {
        const pFmt = '$'+formatPrecio(art.precio);
        pdf.setFont('helvetica','bold'); pdf.setFontSize(22); pdf.setTextColor(...TXT);
        pdf.text(pFmt, 8, cy);
        pdf.setFont('helvetica','normal'); pdf.setFontSize(9); pdf.setTextColor(...GR3);
        pdf.text(art.moneda||'MXN', 8+pdf.getTextWidth(pFmt)+3, cy);
        cy += 12;
      } else {
        pdf.setFont('helvetica','normal'); pdf.setFontSize(10); pdf.setTextColor(...GR3);
        pdf.text('Consultar precio', 8, cy);
        cy += 10;
      }

      cy += 2;
      pdf.setDrawColor(...RED); pdf.setLineWidth(0.5); pdf.line(8, cy, W-8, cy);
      cy += 5;

      /* ÁREA DE IMAGEN — usa todo el espacio restante de la hoja */
      const imgAreaY = cy;
      const footerY  = H - 13;
      const imgAreaH = footerY - cy - 3;
      const GAP = 4, IX = 8, IW = W - IX - M;

      if (images.length === 0) {
        pdf.setFillColor(...GR2); pdf.roundedRect(IX, imgAreaY, IW, imgAreaH, 4, 4, 'F');
        pdf.setFont('helvetica','normal'); pdf.setFontSize(11); pdf.setTextColor(...GR3);
        pdf.text('Sin imagen', W/2, imgAreaY+imgAreaH/2, { align:'center' });
      } else if (images.length === 1) {
        pdf.setFillColor(...GR2); pdf.roundedRect(IX, imgAreaY, IW, imgAreaH, 4, 4, 'F');
        await pdfAddImageFit(pdf, images[0], IX, imgAreaY, IW, imgAreaH, dimsCache);
      } else if (images.length === 2) {
        const cW2 = (IW - GAP) / 2;
        pdf.setFillColor(...GR2);
        pdf.roundedRect(IX,          imgAreaY, cW2, imgAreaH, 4, 4, 'F');
        pdf.roundedRect(IX+cW2+GAP,  imgAreaY, cW2, imgAreaH, 4, 4, 'F');
        await pdfAddImageFit(pdf, images[0], IX,          imgAreaY, cW2, imgAreaH, dimsCache);
        await pdfAddImageFit(pdf, images[1], IX+cW2+GAP,  imgAreaY, cW2, imgAreaH, dimsCache);
      } else {
        const cols = 2;
        const rows = Math.ceil(images.length / cols);
        const cW3  = (IW - GAP*(cols-1)) / cols;
        const cH3  = (imgAreaH - GAP*(rows-1)) / rows;
        for (let j = 0; j < images.length; j++) {
          const col = j % cols, row = Math.floor(j / cols);
          const bx = IX + col*(cW3+GAP), by = imgAreaY + row*(cH3+GAP);
          pdf.setFillColor(...GR2); pdf.roundedRect(bx, by, cW3, cH3, 3, 3, 'F');
          await pdfAddImageFit(pdf, images[j], bx, by, cW3, cH3, dimsCache);
        }
      }

      pdf.setFillColor(...CARD); pdf.rect(0, H-12, W, 12, 'F');
      pdf.setFont('helvetica','normal'); pdf.setFontSize(7); pdf.setTextColor(...GR3);
      pdf.text(footer, W/2, H-4, { align:'center' });

      showPdfProgress(15 + ((i+1)/total)*82, `Artículo ${i+1} de ${total}…`);
      await sleep(15);
    }

    showPdfProgress(100, 'Descargando…'); await sleep(200);
    pdf.save((titleRed+'_'+titleRest).toLowerCase().replace(/\s+/g,'_') + '_catalogo.pdf');
    document.getElementById('modal-pdf-progress').classList.add('hidden');
    showToast('✓ PDF descargado', 'ok');
  } catch(err) {
    document.getElementById('modal-pdf-progress').classList.add('hidden');
    console.error(err);
    showToast('Error PDF: '+err.message, 'err');
  }
}

/* ══════════════════════════════════════════
   EVENT LISTENERS
══════════════════════════════════════════ */
document.getElementById('btn-add-article').addEventListener('click', async () => {
  const art = await addArticle();
  setTimeout(() => {
    const el = document.querySelector(`.article-card[data-id="${art.id}"]`);
    if (el) { el.classList.add('open'); el.scrollIntoView({ behavior:'smooth', block:'center' }); }
  }, 50);
});

document.getElementById('btn-paste-mode').addEventListener('click', () => {
  document.getElementById('paste-panel').classList.toggle('hidden');
});
document.getElementById('btn-paste-cancel').addEventListener('click', () => {
  document.getElementById('paste-panel').classList.add('hidden');
});
document.getElementById('btn-paste-apply').addEventListener('click', async () => {
  const text = document.getElementById('paste-input').value.trim();
  if (!text) { showToast('Pega tu lista primero', 'err'); return; }
  const parsed = parsePastedList(text);
  if (!parsed.length) { showToast('No se detectaron artículos', 'err'); return; }
  for (const p of parsed) await addArticle(p);
  document.getElementById('paste-panel').classList.add('hidden');
  document.getElementById('paste-input').value = '';
  showToast(`✓ ${parsed.length} artículo${parsed.length>1?'s':''} agregado${parsed.length>1?'s':''}`, 'ok');
});

document.getElementById('btn-generate').addEventListener('click', downloadHTML);
document.getElementById('btn-preview').addEventListener('click', showPreview);
document.getElementById('btn-close-preview').addEventListener('click', () => {
  document.getElementById('modal-preview').classList.add('hidden');
});
document.getElementById('btn-gen-pdf').addEventListener('click', generatePDF);
document.getElementById('btn-publicar-tienda').addEventListener('click', exportarParaTienda);

document.getElementById('btn-clear-all').addEventListener('click', clearAllArticles);
document.getElementById('btn-price-list').addEventListener('click', exportPriceListPDF);

document.getElementById('articles-search').addEventListener('input', e => {
  filterArticles(e.target.value);
});

document.getElementById('btn-backup-export').addEventListener('click', exportBackupJSON);
document.getElementById('btn-backup-import').addEventListener('click', () => {
  document.getElementById('backup-import-input').click();
});
document.getElementById('backup-import-input').addEventListener('change', e => {
  const file = e.target.files[0];
  if (file) importBackupJSON(file);
  e.target.value = '';
});

document.getElementById('btn-help').addEventListener('click', openTutorial);
document.getElementById('btn-close-tutorial').addEventListener('click', closeTutorial);
document.getElementById('btn-tutorial-done').addEventListener('click', closeTutorial);

document.querySelectorAll('.theme-opt').forEach(btn => {
  btn.addEventListener('click', () => {
    const theme = btn.dataset.theme;
    document.querySelectorAll('.theme-opt').forEach(b => b.classList.toggle('active', b === btn));
    const input = document.getElementById('cfg-tema');
    input.value = theme;
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });
});

document.getElementById('btn-pdf-import').addEventListener('click', () => {
  document.getElementById('pdf-import-input').click();
});
document.getElementById('pdf-import-input').addEventListener('change', e => {
  const file = e.target.files[0];
  if (file) importFromPDF(file);
  e.target.value = '';
});

document.getElementById('btn-ai-assign').addEventListener('click', () => {
  if (!getCfg('cfg-gemini-key')) { abrirPedirClaveIA(); return; }
  autoAssignPhotosWithAI();
});

/* ARRANQUE */
init();
